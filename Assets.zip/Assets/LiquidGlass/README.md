# liquidglass-unity
This is my attempt to write a unity-targeted light-weight 2D shader that renders the "LiquidGlass" effect characterizing the UI in Apple's IOS 26
